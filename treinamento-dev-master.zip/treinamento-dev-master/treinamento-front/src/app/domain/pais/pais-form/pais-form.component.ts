import { Component, OnInit } from '@angular/core';
import { Pais } from '../pais';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PaisService } from '../pais.service';
import { ActivatedRoute, Router } from '@angular/router';
import Validation from '../../../core/util/validation';

@Component({
  selector: 'app-pais-form',
  templateUrl: './pais-form.component.html',
  styleUrls: ['./pais-form.component.css']
})
export class PaisFormComponent implements OnInit {

  // Declaração de variáveis
  pais: Pais;
  paisForm: FormGroup;
  titulo: string;

  constructor(private paisService: PaisService,
              private builder: FormBuilder,
              private router: Router,
              private route: ActivatedRoute) { }

  ngOnInit() {

    // Instanciar novo pais
    this.pais = new Pais();

    // Obter o ID pela url
    this.pais.id = this.route.snapshot.params['id'];

    // Define o título
    this.titulo = (this.pais.id) ? 'Editar':'Cadastrar';

    // Reactive form
    this.paisForm = this.builder.group({
      id: [],
      nome: ['', Validators.required]
    },{});

    // Busca os dados do pais caso seja o formulário de editar ou visualizar
    if(this.pais.id){
      this.paisService.findById(this.pais.id)
        .subscribe(pais => this.paisForm.patchValue(pais));
    }

    // Desabilitar todos os campos do formulário caso seja visualizar
    if(this.route.snapshot.url[0].path =='visualizar'){
      // Desabilita o formulário
      this.paisForm.disable();

      // Alterar o título da página
      this.titulo = 'Visualizar';
    }
  }

  // Método para salvar os dados do formulário
  onSave(pais: Pais) {

    // Verificar se o formulário esta inválido
    if(this.paisForm.invalid){
      // Valida todos campos do formulário
      Validation.allFormFields(this.paisForm);

      console.log("Formulário esta inválido!");
    } else {
      this.paisService.save(pais)
      .subscribe(pais => {
        console.log("Pais salvo com sucesso!");

        // Redireciona para lista de paises
        this.router.navigate(['/pais']);
      });
    }
  }
}
