export class Pais {
    id: number;
    nome: string;
}
