import { Component, OnInit } from '@angular/core';
import { Pais } from '../pais';
import { PaisService } from '../pais.service';

@Component({
  selector: 'app-pais-list',
  templateUrl: './pais-list.component.html',
  styleUrls: ['./pais-list.component.css']
})
export class PaisListComponent implements OnInit {

  // Declarações de variáveis
  paises: Pais[];

  constructor(private paisService: PaisService) { }

  ngOnInit() {

    // Chama o serviço de buscar todos paises
    this.paisService.findAll()
      .subscribe(paises => this.paises = paises);
  }

  // Método de deleter pais
  onDelete(id: number){

    // Chama o serviço para deletar o pais
    this.paisService.deleteById(id)
      .subscribe(() => {
        // Imprime no console a mensagem
        console.log("Pais deletado com sucesso!");

        // Remove o pais da lista
        this.paises = this.paises.filter(pais => pais.id !== id);
      });
  }
}
