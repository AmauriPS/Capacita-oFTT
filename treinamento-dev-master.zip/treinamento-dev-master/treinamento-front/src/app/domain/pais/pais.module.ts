import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PaisRoutingModule } from './pais-routing.module';
import { PaisListComponent } from './pais-list/pais-list.component';
import { PaisService } from './pais.service';
import { PaisFormComponent } from './pais-form/pais-form.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { FieldComponent } from '../../core/field/field.component';

@NgModule({
  declarations: [
    PaisListComponent, 
    PaisFormComponent, 
    FieldComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    PaisRoutingModule
  ],
  providers: [PaisService]
})
export class PaisModule { }
