import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mantenedora-form',
  templateUrl: './mantenedora-form.component.html',
  styleUrls: ['./mantenedora-form.component.css']
})
export class MantenedoraFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
