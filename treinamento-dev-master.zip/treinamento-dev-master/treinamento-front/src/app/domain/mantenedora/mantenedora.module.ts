import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MantenedoraRoutingModule } from './mantenedora-routing.module';
import { MantenedoraListComponent } from './mantenedora-list/mantenedora-list.component';
import { MantenedoraFormComponent } from './mantenedora-form/mantenedora-form.component';

@NgModule({
  declarations: [MantenedoraListComponent, MantenedoraFormComponent],
  imports: [
    CommonModule,
    MantenedoraRoutingModule
  ]
})
export class MantenedoraModule { }
