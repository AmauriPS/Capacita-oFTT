import { Endereco } from '../endereco/endereco';

export class Mantenedora {
    id: number;
    nome: string;
    razaoSocial: string;
    cnpj: string;
    endereco: Endereco;
}
