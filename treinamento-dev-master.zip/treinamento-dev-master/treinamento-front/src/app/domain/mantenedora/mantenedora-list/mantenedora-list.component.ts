import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mantenedora-list',
  templateUrl: './mantenedora-list.component.html',
  styleUrls: ['./mantenedora-list.component.css']
})
export class MantenedoraListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
