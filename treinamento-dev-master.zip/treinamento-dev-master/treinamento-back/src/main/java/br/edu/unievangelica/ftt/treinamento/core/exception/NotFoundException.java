package br.edu.unievangelica.ftt.treinamento.core.exception;

@SuppressWarnings("serial")
public class NotFoundException extends RuntimeException {
	public NotFoundException() {
		super();
	}
}
