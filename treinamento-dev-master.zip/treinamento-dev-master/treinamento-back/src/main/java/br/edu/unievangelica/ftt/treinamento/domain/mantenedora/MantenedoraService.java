package br.edu.unievangelica.ftt.treinamento.domain.mantenedora;

import org.springframework.stereotype.Service;

import br.edu.unievangelica.ftt.treinamento.core.service.AbstractService;

@Service
public class MantenedoraService extends AbstractService<Mantenedora> {

}
